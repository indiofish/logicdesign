the top module

this module has internal running clock for every value,
and the mode variable only chooses what to display
